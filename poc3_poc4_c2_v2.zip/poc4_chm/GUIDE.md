# POC 4: CHM Help File + C2 Exfil

Pre-compiled help file with embedded JavaScript. Looks like a VPN troubleshooting guide.
Runs enumeration and sends data to C2 beacon listener.

## Chain
```
IT_Troubleshooting_Guide.chm -> hh.exe (Microsoft-signed) -> JavaScript ActiveXObject -> PowerShell enum -> HTTP POST to C2
```

## Enumeration collected
- Hostname, username, domain
- IP address (first non-loopback IPv4)
- OS version
- Running processes (unique names)
- Network connections (ESTABLISHED + LISTENING)

## Setup
1. Edit `content.html` and set `C2_URL` to your C2 server address
2. Recompile the CHM (see below)
3. Make sure the C2 server is running (see `c2_server/GUIDE.md`)
4. Run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup.ps1
```
5. Open Downloads, double-click IT_Troubleshooting_Guide.chm.

## Recompile CHM after editing content.html
```cmd
"C:\Program Files (x86)\HTML Help Workshop\hhc.exe" project.hhp
```
Note: hhc.exe returns exit code 1 on success (this is normal).
If HTML Help Workshop is not installed, download from Microsoft.

## Reset
```powershell
.\cleanup.ps1
```
