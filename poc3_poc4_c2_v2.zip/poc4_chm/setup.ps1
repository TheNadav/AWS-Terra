$root = $PSScriptRoot
$downloads = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads"
$dest = Join-Path $downloads "IT_Troubleshooting_Guide.chm"

Copy-Item "$root\IT_Troubleshooting_Guide.chm" $dest -Force
Unblock-File -Path $dest

Write-Host "Ready. File at: $dest"
Write-Host "Demo: open Downloads, double-click IT_Troubleshooting_Guide.chm"
