$downloads = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads"

Stop-Process -Name hh, powershell -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $downloads "IT_Troubleshooting_Guide.chm") -Force -ErrorAction SilentlyContinue
Write-Host "Clean."
