# Demo C2 Beacon Listener

Lightweight Flask server that receives enumeration data from POC3/POC4 payloads.

## Setup (on your internet-exposed server)

```bash
pip install -r requirements.txt
python c2_server.py
```

Override port with environment variable:
```bash
C2_PORT=8080 python c2_server.py
```

## Endpoints

- `POST /beacon` - receives JSON enumeration data from payloads
- `GET /beacons` - returns all received beacons as JSON
- `GET /beacons/latest` - returns the most recent beacon
- `DELETE /beacons/clear` - clears all stored beacons (reset for next demo)
- `GET /health` - server status check

## Before running POC3/POC4

Update `C2_URL` in the payload files with your server address:
- `poc3_hta/payload.hta` - line near the top of the VBScript block
- `poc4_chm/content.html` - line near the top of the JavaScript block

Replace `http://YOURSERVER:5000` with your actual C2 server address.

## Firewall

Make sure port 5000 (or your custom port) is open for inbound TCP.

## Data

All beacons are saved to `beacons.json` in the same directory.
