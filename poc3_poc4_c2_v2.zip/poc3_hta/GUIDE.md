# POC 3: HTA Benefits Form + C2 Exfil

HTML Application with embedded VBScript. Looks like an HR enrollment form.
Runs enumeration and sends data to C2 beacon listener.

## Chain
```
Benefits_Enrollment_2026.hta -> mshta.exe (Microsoft-signed) -> VBScript -> PowerShell enum -> HTTP POST to C2
```

## Enumeration collected
- Hostname, username, domain
- IP address (first non-loopback IPv4)
- OS version
- Running processes (unique names)
- Network connections (ESTABLISHED + LISTENING)

## Setup
1. Edit `payload.hta` and set `C2_URL` to your C2 server address
2. Make sure the C2 server is running (see `c2_server/GUIDE.md`)
3. Run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup.ps1
```
4. Open Downloads, extract ZIP, double-click the HTA file.

## Reset
```powershell
.\cleanup.ps1
```
