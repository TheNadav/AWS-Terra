$downloads = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads"

Stop-Process -Name mshta, powershell -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $downloads "Benefits_Enrollment_2026") -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $downloads "Benefits_Enrollment_2026.zip") -Force -ErrorAction SilentlyContinue
Write-Host "Clean."
